# Create first 'string' variable
name = 'Mike'
profession = "writer"

# Create variable containing 'integer'
books_written = 6

# Concatenate and print out variables
output = name + ' is a ' + profession + " and he's written " + str(books_written) + " books."
output_2 = f"{name} is a {profession} and he's written {books_written} books."

print(output_2)
