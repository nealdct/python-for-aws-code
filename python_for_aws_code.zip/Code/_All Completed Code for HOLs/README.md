# About the Completed Code

Inside this folder, you'll find the fully-baked code for every hands-on challenge. We totally recommend riding shotgun with Eric and typing out the code alongside him—it's the best way to let the knowledge really sink in! 🚀

But hey, if you hit a coding pothole or just wanna skip ahead to see how the magic's done, these code snippets are your backstage pass. Code on! 🎸🤓

*** Note: Other code such as JSON policies, CSV files, YAML templates etc. can be found in the folders alongside this one - go back up a level ⬆️ ***