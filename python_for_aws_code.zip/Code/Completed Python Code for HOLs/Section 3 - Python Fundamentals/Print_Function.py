# print string
#print("Hello World!")

# print an integer
#print(32)

# Concatenate and print
print("Hello World!\n" + str(32))